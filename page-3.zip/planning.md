H1 header
Font: Arial, strong
Font colour:


Colour palette:
#76519b
#7b79b5
#7ba0cf
#9bc4d5
#bce8d8 